-- Object dropper for BullySkate (BullyMotion): place rails, ramps, benches and other props.
--
-- Open:  RB + B  (keyboard F3), or "Object dropper" in the F8 skate menu.
--   LS ............ move the object          RS ............ turn the camera (up / down = zoom)
--   LB / RB ....... rotate the object        LT / RT ....... lower / raise the object
--   LS click ...... put the object back on the ground
--   D-pad Up/Down . change category          D-pad L / R ... change object
--   A ............. drop it                   X ............. remove the nearest object
--   Y ............. pick up the nearest object (move it)
--   Back .......... remove all (press twice)  B ............. done
--
-- The props are the game's own models. Their collision and grind rails are added to
-- BullySkate's world files (assets/world.bmgeo and world.bmrails) and the skate physics
-- reloads them when you press B, so you can skate and grind them. Your objects are saved
-- and come back next time you play.

LoadScript("dropper_catalog.lua")

DROP_MAX = 24
DROP_ROT_SIGN = 1   -- flip to -1 if an object's collision ever faces the other way to its model
DROP_DIR = "_derpy_script_loader/scripts/BullyMotion/"
DROP_ASSETS = DROP_DIR .. "assets/"

dropper = nil            -- non-nil while the dropper is open
DR = { objects = {}, needReload = false, base = nil }

------------------------------------------------------------------ small helpers
function DR_log(s)
	print("[Dropper] " .. s)
	pcall(function()
		local f = io.open(DROP_DIR .. "dropper_debug.txt", "a")
		if f then f:write(s .. "\n"); f:close() end
	end)
end

function DR_item(cat, i)
	local list = DROP_ITEMS[DROP_CATS[cat]]
	return list and list[i]
end

function DR_findItem(model)
	for c = 1, table.getn(DROP_CATS) do
		local list = DROP_ITEMS[DROP_CATS[c]]
		for i = 1, table.getn(list) do
			if list[i].model == model then return list[i], c, i end
		end
	end
	return nil
end

-- little-endian binary writers (Lua 5.0 has no string.pack)
function DR_u16(v) return string.char(math.mod(v, 256), math.floor(v / 256)) end
function DR_u32(v)
	return string.char(math.mod(v, 256), math.mod(math.floor(v / 256), 256), math.mod(math.floor(v / 65536), 256), math.floor(v / 16777216))
end
function DR_rdu32(s, i)
	return string.byte(s, i) + string.byte(s, i + 1) * 256 + string.byte(s, i + 2) * 65536 + string.byte(s, i + 3) * 16777216
end
function DR_f32(x)
	if x == 0 then return "\0\0\0\0" end
	local sign = 0
	if x < 0 then sign = 1; x = -x end
	local m, e = math.frexp(x)          -- x = m * 2^e, 0.5 <= m < 1
	local E = e + 126
	if E <= 0 then return "\0\0\0\0" end
	if E >= 255 then E = 254; m = 0.99999994 end
	local mant = math.floor((m * 2 - 1) * 8388608 + 0.5)
	if mant >= 8388608 then mant = 0; E = E + 1 end
	return string.char(math.mod(mant, 256), math.mod(math.floor(mant / 256), 256),
		math.floor(mant / 65536) + math.mod(E, 2) * 128, math.floor(E / 2) + sign * 128)
end

-- Bully world (Z up) -> BullySkate core coordinates (Y up): core = [x, z, -y]
function DR_core(x, y, z) return DR_f32(x) .. DR_f32(z) .. DR_f32(-y) end

function DR_place(o, lx, ly, lz)
	local h = o.h * math.pi / 180 * DROP_ROT_SIGN
	local c, s = math.cos(h), math.sin(h)
	return o.x + lx * c - ly * s, o.y + lx * s + ly * c, o.z + lz
end

------------------------------------------------------------------ game entities
function DR_spawn(o)
	local ok, id, pool = pcall(CreatePersistentEntity, o.model, o.x, o.y, o.z, o.h, o.area)
	if ok and id then o.id, o.pool = id, pool; return true end
	DR_log("could not create " .. o.model .. ": " .. tostring(id))
	return false
end

function DR_despawn(o)
	if o and o.id then pcall(DeletePersistentEntity, o.id, o.pool) end
	if o then o.id, o.pool = nil, nil end
end

------------------------------------------------------------------ world files
function DR_readFile(path)
	local f = io.open(path, "rb")
	if not f then return nil end
	local d = f:read("*a"); f:close(); return d
end

-- parts: a string or a list of strings written one after another
function DR_writeFile(path, parts)
	local f = io.open(path, "wb")
	if not f then return false end
	if type(parts) == "string" then f:write(parts)
	else for i = 1, table.getn(parts) do f:write(parts[i]) end end
	f:close(); return true
end

-- Bully's Lua numbers are 32-bit floats, so file sizes (17 MB) can't be stored exactly.
-- The triangle / rail counts in the file headers are small enough, so those are what we track.
function DR_loadState()
	local s = DR_readFile(DROP_DIR .. "dropper_state.txt") or ""
	local _, _, g = string.find(s, "geocount=(%d+)")
	local _, _, r = string.find(s, "railcount=(%d+)")
	return tonumber(g), tonumber(r)
end

-- the untouched world files. They are only re-taken if something else (e.g. the BullySkate
-- launcher) replaced world.bmgeo / world.bmrails since our last write.
function DR_baseFiles()
	local geo = DR_readFile(DROP_ASSETS .. "world.bmgeo")
	local rails = DR_readFile(DROP_ASSETS .. "world.bmrails")
	if not geo or not rails then return nil, nil, "cannot read the world files" end
	local lastGeo, lastRails = DR_loadState()
	local baseGeo = DR_readFile(DROP_ASSETS .. "world.bmgeo.base")
	local baseRails = DR_readFile(DROP_ASSETS .. "world.bmrails.base")
	if not baseGeo or (lastGeo and DR_rdu32(geo, 9) ~= lastGeo) then
		baseGeo = geo
		if not DR_writeFile(DROP_ASSETS .. "world.bmgeo.base", geo) then return nil, nil, "cannot back up world.bmgeo" end
		DR_log("world.bmgeo base taken from the current file")
	end
	if not baseRails or (lastRails and DR_rdu32(rails, 9) ~= lastRails) then
		baseRails = rails
		if not DR_writeFile(DROP_ASSETS .. "world.bmrails.base", rails) then return nil, nil, "cannot back up world.bmrails" end
		DR_log("world.bmrails base taken from the current file")
	end
	if string.sub(baseGeo, 1, 8) ~= "BMGEO2\0\0" or string.sub(baseRails, 1, 8) ~= "BMRL3\0\0\0" then
		return nil, nil, "unexpected world file format"
	end
	return baseGeo, baseRails
end

-- write world.bmgeo / world.bmrails = original + every dropped object's collision and rails
function DR_writeWorld()
	local baseGeo, baseRails, why = DR_baseFiles()
	if not baseGeo then return false, why end
	local geo, rails = {}, {}
	local ntri, nrail = 0, 0
	for k = 1, table.getn(DR.objects) do
		local o = DR.objects[k]
		local item = DR_findItem(o.model)
		if item then
			local t = item.tris
			for i = 1, table.getn(t), 9 do
				local tri = {}
				for v = 0, 2 do
					local x, y, z = DR_place(o, t[i + v * 3], t[i + v * 3 + 1], t[i + v * 3 + 2])
					tri[v + 1] = DR_core(x, y, z)
				end
				local mat = item.mats[(i - 1) / 9 + 1] or 0
				-- mirrored rotation flips the winding, so keep faces pointing outward
				if DROP_ROT_SIGN < 0 then tri[2], tri[3] = tri[3], tri[2] end
				table.insert(geo, tri[1] .. tri[2] .. tri[3] .. DR_u16(mat) .. DR_u16(o.area) .. DR_u32(65000))
				ntri = ntri + 1
			end
			for r = 1, table.getn(item.rails) do
				local rail = item.rails[r]
				local pts = {}
				local n = (table.getn(rail) - 1) / 3
				for p = 0, n - 1 do
					local x, y, z = DR_place(o, rail[2 + p * 3], rail[3 + p * 3], rail[4 + p * 3])
					table.insert(pts, DR_core(x, y, z))
				end
				table.insert(rails, DR_u16(o.area) .. DR_u16(rail[1]) .. DR_u32(n) .. table.concat(pts))
				nrail = nrail + 1
			end
		end
	end
	local geoCount = DR_rdu32(baseGeo, 9) + ntri
	local railCount = DR_rdu32(baseRails, 9) + nrail
	if railCount > 65535 then return false, "too many grind rails" end
	local g = table.concat(geo)
	local r = table.concat(rails)
	if not DR_writeFile(DROP_ASSETS .. "world.bmgeo", { "BMGEO2\0\0", DR_u32(geoCount), string.sub(baseGeo, 13), g }) then return false, "cannot write world.bmgeo" end
	if not DR_writeFile(DROP_ASSETS .. "world.bmrails", { "BMRL3\0\0\0", DR_u32(railCount), string.sub(baseRails, 13), r }) then return false, "cannot write world.bmrails" end
	DR_writeFile(DROP_DIR .. "dropper_state.txt", string.format("geocount=%d\nrailcount=%d\n", geoCount, railCount))
	DR.needReload = true
	DR_log(string.format("world written: %d objects, %d triangles, %d rails", table.getn(DR.objects), ntri, nrail))
	return true
end

-- The skate worker only re-reads the world files when the area changes, so mount once in
-- another area first; the real mount right after then loads the new files.
function DropperBeforeMount(x, y, z, yaw)
	if not DR.needReload then return end
	DR.needReload = false
	local area = AreaGetVisible()
	local other = 4
	if area == 4 then other = 2 end
	local ok, h = pcall(FS_SkateNew, x, y, z, yaw, other)
	if ok and h then FS_SkateFree(h) end
	DR_log("skate world reloaded (via area " .. other .. ")")
end

------------------------------------------------------------------ saving
function DR_save()
	local lines = {}
	for k = 1, table.getn(DR.objects) do
		local o = DR.objects[k]
		table.insert(lines, string.format("%s %d %.3f %.3f %.3f %.1f", o.model, o.area, o.x, o.y, o.z, o.h))
	end
	DR_writeFile(DROP_DIR .. "dropper_objects.txt", table.concat(lines, "\n") .. "\n")
end

-- at game start: bring back saved objects and make sure the world files match them
function DropperBoot()
	local s = DR_readFile(DROP_DIR .. "dropper_objects.txt")
	if not s then return end
	for model, area, x, y, z, h in string.gfind(s, "(%S+) (%-?%d+) (%-?[%d%.]+) (%-?[%d%.]+) (%-?[%d%.]+) (%-?[%d%.]+)") do
		if DR_findItem(model) then
			local o = { model = model, area = tonumber(area), x = tonumber(x), y = tonumber(y), z = tonumber(z), h = tonumber(h) }
			DR_spawn(o)
			table.insert(DR.objects, o)
		end
	end
	if table.getn(DR.objects) > 0 then
		local ok, why = DR_writeWorld()
		if not ok then DR_log("boot: " .. tostring(why)) end
	end
end

function DropperCleanup()
	for k = 1, table.getn(DR.objects) do DR_despawn(DR.objects[k]) end
	if dropper then DR_despawn(dropper.preview) end
end

------------------------------------------------------------------ open / close
function DropperOpen()
	if dropper then return end
	if GetCutsceneRunning() ~= 0 or PlayerIsInAnyVehicle() then say("Use the object dropper on foot or on your board"); return end
	if replay then ReplayClose() end
	if debugCamera then DebugCameraClose(false) end
	SkateAudioStop()
	local x, y, z = PlayerGetPosXYZ()
	local hd = PedGetHeading(gPlayer)
	dropper = {
		cat = 1, item = 1, h = math.floor(hd * 180 / math.pi + 0.5),
		cx = x - math.sin(hd) * 5, cy = y + math.cos(hd) * 5, cz = z, lift = 0,
		yaw = hd, pitch = 0.75, dist = 11, changed = false, wasSkating = (mode == 1),
		preview = nil, previewAt = 0, clearArm = 0, toast = nil, toastEnd = 0, held = {},
		waitRelease = true,   -- the RB + B that opened it must be let go before B / RB do anything
	}
	dropper.cz = DR_ground(dropper.cx, dropper.cy, z)
	if mode ~= 1 then PlayerSetControl(0) end
	pcall(HUDSaveVisibility); pcall(HUDClearAllElements)
	DR_toast("Object Dropper", 1500)
end

function DR_toast(s, ms) if dropper then dropper.toast = s; dropper.toastEnd = GetTimer() + (ms or 2500) end end

function DropperClose(apply)
	local D = dropper
	if not D then return end
	DR_despawn(D.preview)
	dropper = nil
	pcall(HUDRestoreVisibility)
	FS_View(); pcall(CameraReturnToPlayer); pcall(CameraReset); pcall(CameraDefaultFOV)
	if mode ~= 1 then PlayerSetControl(1) end
	if apply and D.changed then
		DR_save()
		local ok, why = DR_writeWorld()
		if not ok then say("Objects placed, but the skate world could not be updated: " .. tostring(why)); return end
		if D.wasSkating and mode == 1 then
			say("Updating the skate world...")
			switch()                 -- back to Bully controls
			switch()                 -- and straight back on the board with the new world
		else
			say("Objects ready - they'll be skateable when you get on your board")
		end
	end
end

------------------------------------------------------------------ placement
function DR_ground(x, y, zHint)
	local ok, hx, hy, hz = FS_Trace(x, y, zHint + 4, x, y, zHint - 12)
	if ok then return hz end
	return zHint
end

function DR_current()
	local D = dropper
	return DR_item(D.cat, D.item)
end

-- recreate the preview prop where the cursor is
function DR_refreshPreview(force)
	local D = dropper
	local now = GetTimer()
	local item = DR_current()
	if not item then return end
	local moved = not D.pv or math.abs(D.pv.x - D.cx) > 0.12 or math.abs(D.pv.y - D.cy) > 0.12 or D.pv.h ~= D.h or D.pv.model ~= item.model or math.abs(D.pv.lift - D.lift) > 0.04
	if not force and (not moved or now < D.previewAt) then return end
	D.previewAt = now + 140
	DR_despawn(D.preview)
	D.cz = DR_ground(D.cx, D.cy, D.cz)
	local o = { model = item.model, area = AreaGetVisible(), x = D.cx, y = D.cy, z = D.cz - item.minz + D.lift, h = D.h }
	D.previewOk = DR_spawn(o)
	D.preview = o
	D.pv = { x = D.cx, y = D.cy, h = D.h, model = item.model, lift = D.lift }
end

function DR_nearest()
	local D = dropper
	local best, bd = nil, 1e9
	for k = 1, table.getn(DR.objects) do
		local o = DR.objects[k]
		local item = DR_findItem(o.model)
		local d = math.sqrt((o.x - D.cx) * (o.x - D.cx) + (o.y - D.cy) * (o.y - D.cy)) - (item and item.radius or 1) * 0.6
		if d < bd then best, bd = k, d end
	end
	if best and bd < 2.5 then return best end
	return nil
end

function DR_drop()
	local D = dropper
	local item = DR_current()
	if not item then return end
	if table.getn(DR.objects) >= DROP_MAX then DR_toast("That's the limit (" .. DROP_MAX .. " objects) - remove some first"); return end
	if not D.previewOk then DR_toast("This object can't be placed here"); return end
	local o = D.preview
	D.preview = nil; D.pv = nil      -- the preview prop becomes the real one
	table.insert(DR.objects, o)
	D.changed = true
	DR_toast(item.label .. " dropped (" .. table.getn(DR.objects) .. "/" .. DROP_MAX .. ")", 1500)
	DR_refreshPreview(true)
end

function DR_remove(pickUp)
	local D = dropper
	local k = DR_nearest()
	if not k then DR_toast("Move closer to an object you placed"); return end
	local o = table.remove(DR.objects, k)
	DR_despawn(o)
	D.changed = true
	if pickUp then
		local item, c, i = DR_findItem(o.model)
		if item then D.cat, D.item = c, i end
		D.cx, D.cy, D.h = o.x, o.y, o.h
		if item then D.cz = DR_ground(o.x, o.y, o.z + item.minz); D.lift = math.floor((o.z + item.minz - D.cz) * 20 + 0.5) / 20 end
		DR_toast("Picked up " .. (item and item.label or o.model))
	else
		DR_toast("Removed")
	end
	DR_refreshPreview(true)
end

------------------------------------------------------------------ one frame
function DropperUpdate(now, dt, buttons, lx, ly, rx, ry, lt, rt, pressed)
	local D = dropper
	if not D then return end
	if GetCutsceneRunning() ~= 0 or not PedIsValid(gPlayer) then DropperClose(false); return end
	local _, kEsc = key(27); local _, kEnter = key(13); local _, kDel = key(46)
	local dead = 0.18
	if math.abs(lx) < dead then lx = 0 end
	if math.abs(ly) < dead then ly = 0 end
	if math.abs(rx) < dead then rx = 0 end
	if math.abs(ry) < dead then ry = 0 end
	D.held.lb = bit(buttons, 256); D.held.rb = bit(buttons, 512)
	if D.waitRelease then
		if not bit(buttons, 8192) and not bit(buttons, 512) then D.waitRelease = false end
		local raw = pressed
		pressed = function(n) if n == 8192 or n == 512 then return false end return raw(n) end
		D.held.rb = false
	end

	if pressed(8192) or kEsc then DropperClose(true); return end
	if pressed(4096) or kEnter then DR_drop() end
	if pressed(16384) or kDel then DR_remove(false) end
	if pressed(32768) then DR_remove(true) end
	if pressed(32) then
		if now < D.clearArm then
			for k = 1, table.getn(DR.objects) do DR_despawn(DR.objects[k]) end
			DR.objects = {}; D.changed = true; D.clearArm = 0
			DR_toast("All objects removed")
		else
			D.clearArm = now + 2500
			DR_toast("Press Back again to remove all " .. table.getn(DR.objects) .. " objects", 2500)
		end
	end
	local ncat = table.getn(DROP_CATS)
	if pressed(1) then D.cat = math.mod(D.cat - 2 + ncat, ncat) + 1; D.item = 1 end
	if pressed(2) then D.cat = math.mod(D.cat, ncat) + 1; D.item = 1 end
	local count = table.getn(DROP_ITEMS[DROP_CATS[D.cat]])
	if pressed(4) then D.item = math.mod(D.item - 2 + count, count) + 1 end
	if pressed(8) then D.item = math.mod(D.item, count) + 1 end

	-- rotate: tap = 15 degrees, hold = smooth
	if pressed(256) then D.h = D.h + 15; D.rotHeld = now + 300 end
	if pressed(512) then D.h = D.h - 15; D.rotHeld = now + 300 end
	if (D.held.lb or D.held.rb) and now > (D.rotHeld or 0) then
		if D.held.lb then D.h = D.h + 90 * dt end
		if D.held.rb then D.h = D.h - 90 * dt end
	end
	D.h = math.mod(D.h + 360, 360)
	D.h = math.floor(D.h + 0.5)

	-- camera orbit and zoom
	D.yaw = D.yaw - rx * 2.2 * dt
	D.dist = clamp(D.dist - ry * 14 * dt, 3, 40)
	D.pitch = 0.35 + 0.5 * clamp((D.dist - 3) / 20, 0, 1)
	-- height: LT lowers, RT raises (faster the harder you press); LS click = back on the ground
	local lift = rt - lt
	if math.abs(lift) > 0.08 then D.lift = clamp(D.lift + lift * math.abs(lift) * 2.5 * dt, -3, 12) end
	if pressed(64) then D.lift = 0; DR_toast("Back on the ground", 1200) end
	-- move the cursor relative to the camera
	local sp = 4 + D.dist * 0.6
	local fx, fy = -math.sin(D.yaw), math.cos(D.yaw)   -- camera looks along the cursor's "forward"
	D.cx = D.cx + (fx * ly + fy * lx) * sp * dt
	D.cy = D.cy + (fy * ly - fx * lx) * sp * dt
	-- keep the cursor near Jimmy
	local px, py = PlayerGetPosXYZ()
	local ddx, ddy = D.cx - px, D.cy - py
	local dd = math.sqrt(ddx * ddx + ddy * ddy)
	if dd > 60 then D.cx = px + ddx / dd * 60; D.cy = py + ddy / dd * 60 end

	DR_refreshPreview(false)

	local tz = D.cz + 0.5
	local cp = math.cos(D.pitch)
	local camx = D.cx - fx * cp * D.dist
	local camy = D.cy - fy * cp * D.dist
	local camz = tz + math.sin(D.pitch) * D.dist
	local vx, vy, vz = D.cx - camx, D.cy - camy, tz - camz
	local l = math.sqrt(vx * vx + vy * vy + vz * vz)
	CameraSetXYZ(camx, camy, camz, D.cx, D.cy, tz)
	CameraSetFOV(70)
	FS_View(camx, camy, camz, vx / l, vy / l, vz / l, 70)
end

------------------------------------------------------------------ drawing
function DropperDraw()
	local D = dropper
	if not D then return end
	local now = GetTimer()
	-- category tabs
	local n = table.getn(DROP_CATS)
	local tw, gap = 0.12, 0.006
	local x0 = 0.5 - (n * tw + (n - 1) * gap) / 2
	for c = 1, n do
		local x = x0 + (c - 1) * (tw + gap)
		if c == D.cat then
			DrawRectangle(x, 0.060, tw, 0.044, 232, 241, 250, 240)
			DrawRectangle(x, 0.100, tw, 0.004, 238, 140, 40, 255)
			RE_label(DROP_CATS[c], x + tw / 2 - RE_textW(DROP_CATS[c], 0.026) / 2, 0.068, 0.026, 25, 35, 55)
		else
			DrawRectangle(x, 0.060, tw, 0.044, 30, 32, 36, 215)
			RE_label(DROP_CATS[c], x + tw / 2 - RE_textW(DROP_CATS[c], 0.026) / 2, 0.068, 0.026, 220, 225, 232)
		end
	end
	RE_icon("btn_dpad_u", x0 - 0.034, 0.062, 0.04)
	RE_icon("btn_dpad_d", x0 + n * (tw + gap), 0.062, 0.04)
	-- current object
	local item = DR_current()
	local list = DROP_ITEMS[DROP_CATS[D.cat]]
	local name = item and item.label or "?"
	DrawRectangle(0.36, 0.112, 0.28, 0.05, 30, 32, 36, 215)
	RE_icon("btn_dpad_l", 0.364, 0.117, 0.04)
	RE_icon("btn_dpad_r", 0.612, 0.117, 0.04)
	RE_label(name, 0.5 - RE_textW(name, 0.028) / 2, 0.121, 0.028)
	local sub = D.item .. " / " .. table.getn(list) .. "     rotation " .. D.h .. " deg     height " .. string.format("%+.2f", D.lift) .. " m"
	RE_label(sub, 0.5 - RE_textW(sub, 0.018) / 2, 0.168, 0.018, 200, 210, 225)
	if not D.previewOk then RE_label("This object could not be created here", 0.5 - RE_textW("This object could not be created here", 0.02) / 2, 0.192, 0.02, 232, 96, 86) end

	-- stick help + toast + count
	local s = 0.022
	local x = 0.178
	local help = { { "btn_ls", "Move" }, { "btn_rs", "Camera / Zoom" }, { "btn_lb", "" }, { "btn_rb", "Rotate" }, { "btn_lt", "" }, { "btn_rt", "Lower / Raise" }, { "btn_ls_click", "Ground" } }
	for i = 1, table.getn(help) do
		local w = RE_icon(help[i][1], x, 0.822, 0.036)
		x = x + w + 0.002
		if help[i][2] ~= "" then RE_label(help[i][2], x, 0.83, s); x = x + RE_textW(help[i][2], s) + 0.014 end
	end
	if D.toast and now < D.toastEnd then RE_label(D.toast, 0.18, 0.790, 0.024, 255, 214, 120) end
	local cnt = "Objects: " .. table.getn(DR.objects) .. " / " .. DROP_MAX
	RE_label(cnt, 0.815 - RE_textW(cnt, s), 0.83, s, 232, 96, 86)

	-- bottom bar
	DrawRectangle(0.175, 0.872, 0.642, 0.046, 58, 80, 124, 175)
	DrawRectangle(0.175, 0.872, 0.642, 0.002, 205, 220, 240, 230)
	DrawRectangle(0.175, 0.916, 0.642, 0.002, 205, 220, 240, 230)
	RE_label("Object Dropper", 0.184, 0.881, 0.025)
	RE_prompts({ { "btn_a", "Drop" }, { "btn_y", "Pick Up" }, { "btn_x", "Remove" }, { "btn_back", "Clear" }, { "btn_b", "Done" } }, 0.811, 0.881, 0.025)
end

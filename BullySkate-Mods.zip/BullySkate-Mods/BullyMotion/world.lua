-- World options for the skate menu (F8). Saved in world_settings.txt.
-- worldOptions[1]: pedestrians       0 = on, 1 = off
-- worldOptions[2]: mission prompts   0 = hidden while skating, 1 = shown
worldOptions = { 0, 0 }
worldApplied = nil

function WorldLoad()
	local ok = pcall(function()
		local f = OpenFile("world_settings.txt", "r")
		if f then
			local s = ReadFile(f, 64) or ""; CloseFile(f)
			local _, _, v = string.find(s, "pedestrians=(%d)")
			if v then worldOptions[1] = tonumber(v) end
			local _, _, p = string.find(s, "prompts=(%d)")
			if p then worldOptions[2] = tonumber(p) end
		end
	end)
	WorldApply(true)
end

function WorldSave()
	pcall(function()
		local f = OpenFile("world_settings.txt", "w")
		if f then WriteFile(f, "pedestrians=" .. worldOptions[1] .. "\nprompts=" .. worldOptions[2] .. "\n"); CloseFile(f) end
	end)
end

-- clearNow: also remove the people already standing around
function WorldApply(clearNow)
	local off = worldOptions[1] == 1
	if off then
		pcall(StopPedProduction, true)
		if clearNow then pcall(AreaClearAllPeds) end
	elseif worldApplied then
		pcall(StopPedProduction, false)
	end
	worldApplied = off
end

-- new area (going inside / outside): its people spawn fresh, so clear them again
function WorldAreaChanged()
	if worldOptions[1] == 1 then WorldApply(true) end
end

function WorldCleanup()
	if worldApplied then pcall(StopPedProduction, false) end
end

-- every frame: while on the board, wipe the game's mission / objective text.
-- The help boxes (TutorialRemoveMessage) are left alone: the game shows many of them
-- again straight away, and every re-show plays the help-box beep.
function WorldSkateFrame()
	if mode ~= 1 or worldOptions[2] ~= 0 then return end
	pcall(TextClear)
	local ok, n = pcall(GetTextQueueSize)
	if not ok or (type(n) == "number" and n > 0) then pcall(ClearTextQueue) end
end

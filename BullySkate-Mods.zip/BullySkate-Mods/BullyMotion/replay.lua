-- Replay editor add-on for BullySkate (BullyMotion), laid out like Skate 3's replay editor.
-- Written for BullySkate v0.1.2.
--
-- While you skate, the last REPLAY_SECONDS of Jimmy's full skeleton pose, board pose,
-- position and camera are recorded every frame. Opening the editor freezes the skate
-- simulation and plays that recording back through BullySkate's own rig.
--
-- Open / close:  Right stick click + D-pad Up   (keyboard: F4)
--
-- EDIT TIMELINE (whole recording)            EDIT CLIP (A - zoomed in on your clip)
--   RB ............ play / pause               same transport and keyframe buttons
--   LT / RT ....... rewind / fast forward      Y ...... change camera
--   D-pad Down .... set keyframe               X ...... clip speed from this keyframe
--   D-pad Up ...... remove keyframe            A / B .. back to the timeline
--   D-pad L / R ... jump between keyframes
--   LB + LS ....... choose clip start          Sticks move the camera you are setting up:
--   LB + RS ....... choose clip end              Follow / Fisheye: RS orbit, LS distance
--   Y ............. change camera                Tripod / Fixed / Advanced: LS fly, RS look
--   A ............. edit clip                  then D-pad Down keeps it as a keyframe.
--   X ............. take photo (free camera, then F12 for a Steam screenshot)
--   B ............. exit      Back ... help      LS click ... hide everything
--
-- Each keyframe holds a camera; the camera glides smoothly from each keyframe to the next
-- (Follow / Fisheye keyframes swing around Jimmy, the others fly between positions).
-- Keyboard: Space play, arrows scrub, Enter = A, C = Y, K = set keyframe, Delete = remove,
-- P = photo, H = hide, F1 = help, Esc = back.

REPLAY_SECONDS = 60
REPLAY_CAPACITY = REPLAY_SECONDS * 75

replay = nil                    -- non-nil while the editor is open
RP = { frames = {}, head = 0, count = 0, base = nil, checked = false, ok = false, why = "", lastRec = 0 }

------------------------------------------------------------------ BullySkate memory
-- Offsets inside BullySkate.asi v0.1.2 (preferred base 0x10000000), taken from its
-- FS_SkateStep: snapshot pose/board are copied into rig_pose/board_pose, which the
-- plugin's render hook applies to Jimmy while rig_active is 1.
RP_OFF_STEP = 20912        -- 0x51b0 FS_SkateStep handler (version check)
RP_OFF_STEP_MOV = 21170    -- 0x52b2 imm32 of "mov esi, snapshot.pose" (version check)
RP_OFF_SNAP_POSE = 107640  -- 0x1a478
RP_OFF_RIG_ACTIVE = 111672 -- 0x1b438
RP_OFF_RIG_POSE = 111680   -- 0x1b440  36 x 13 floats
RP_OFF_BOARD_POSE = 113552 -- 0x1bb90   2 x 13 floats
RP_POSE_BYTES = 36 * 13 * 4
RP_BOARD_BYTES = 2 * 13 * 4

RP_DEBUG = {}
local function rpLog(s)
	print("[Replay] " .. s)
	table.insert(RP_DEBUG, s)
	pcall(function()
		local f = OpenFile("replay_debug.txt", "w")
		if f then WriteFile(f, table.concat(RP_DEBUG, "\n") .. "\n"); CloseFile(f) end
	end)
end

local function asNumber(v)
	if type(v) == "number" then return v end
	if type(v) == "userdata" then
		local ok, inner = pcall(function() return v.value end)
		if ok and type(inner) == "number" then return inner end
		local hex = string.gsub(tostring(v), "^.-0x", "")
		return tonumber(hex, 16)
	end
	return nil
end

-- IMPORTANT: Bully's Lua stores every number as a 32-bit float (about 7 digits), so a
-- full memory address can't be held in a Lua number without rounding. Addresses are
-- kept as two exact 16-bit halves {hi, lo}, and real pointers are built from an exact
-- game pointer (PedGetPointer) using only small, exactly-representable steps.
local function hexHL(hex)
	if not hex then return nil end
	hex = string.rep("0", 8 - string.len(hex)) .. hex
	if string.len(hex) ~= 8 then return nil end
	return { tonumber(string.sub(hex, 1, 4), 16), tonumber(string.sub(hex, 5, 8), 16) }
end
local function hlText(a) if not a then return "nil" end return string.format("%04X%04X", a[1], a[2]) end
local function hlEq(a, b) return a and b and a[1] == b[1] and a[2] == b[2] end
local function hlAdd(a, n) -- n: small non-negative offset (< 2^24)
	local lo = a[2] + math.mod(n, 65536)
	local hi = a[1] + math.floor(n / 65536)
	if lo >= 65536 then lo = lo - 65536; hi = hi + 1 end
	return { hi, lo }
end
local function hlSub(a, n)
	local lo = a[2] - math.mod(n, 65536)
	local hi = a[1] - math.floor(n / 65536)
	if lo < 0 then lo = lo + 65536; hi = hi - 1 end
	return { hi, lo }
end
local function ptrHL(p)
	local t = tostring(p)
	local _, _, hex = string.find(t, "0[xX](%x+)")
	if not hex then _, _, hex = string.find(t, "(%x+)%s*$") end
	return hexHL(hex)
end
local STEP = 16711680 -- 255 * 65536, exact in a float
function mkptr(a)
	local p = PedGetPointer(gPlayer)
	local a0 = ptrHL(p)
	if not a0 or not a then return nil end
	local dh, dl = a[1] - a0[1], a[2] - a0[2]
	while dh >= 255 do p = p + STEP; dh = dh - 255 end
	while dh <= -255 do p = p - STEP; dh = dh + 255 end
	if dh > 0 then p = p + dh * 65536 elseif dh < 0 then p = p - (-dh) * 65536 end
	if dl > 0 then p = p + dl elseif dl < 0 then p = p - (-dl) end
	if not hlEq(ptrHL(p), a) then
		rpLog("pointer build mismatch: wanted " .. hlText(a) .. " got " .. tostring(p))
		return nil
	end
	return p
end

-- read a little-endian uint32 as {hi, lo}
local function rd32(a)
	local p = mkptr(a)
	if not p then return nil end
	local ok, b = pcall(GetString, p, 4)
	if not ok or type(b) ~= "string" or string.len(b) < 4 then return nil end
	return { string.byte(b, 3) + string.byte(b, 4) * 256, string.byte(b, 1) + string.byte(b, 2) * 256 }
end

-- Find BullySkate.asi in memory WITHOUT calling any Windows functions (v1 crashed doing
-- that). Every Lua C function object stores its C entry point; FS_SkateStep's entry is
-- BullySkate's handler at module base + 0x51b0. Only plain memory reads are used, and
-- each candidate is sanity-checked before anything at that address is touched.
local function closureAddress(fn)
	local _, _, hex = string.find(tostring(fn), ":%s*0?[xX]?(%x+)")
	return hexHL(hex)
end

-- crash guard: if a previous detection attempt never finished (game crashed), don't retry
local function guardRead()
	local f, n = OpenFile("replay_guard.txt", "r")
	if not f then return nil end
	local s = ReadFile(f, 64); CloseFile(f); return s
end
local function guardWrite(s)
	local f = OpenFile("replay_guard.txt", "w")
	if f then WriteFile(f, s); CloseFile(f) end
end

function ReplayFindPlugin()
	if RP.checked then return RP.ok end
	RP.checked = true
	local okG, g = pcall(guardRead)
	if okG and g and string.find(g, "started", 1, true) then
		RP.why = "it crashed during setup last time, so it is switched off (delete BullyMotion/replay_guard.txt to retry)"
		rpLog(RP.why)
		return false
	end
	pcall(guardWrite, "started")
	local ok = ReplayFindPluginInner()
	pcall(guardWrite, ok and "ok" or "failed")
	return ok
end

function ReplayFindPluginInner()
	if type(FS_SkateStep) ~= "function" then RP.why = "FS_SkateStep missing"; rpLog(RP.why); return false end
	local cl = closureAddress(FS_SkateStep)
	rpLog("FS_SkateStep object " .. tostring(FS_SkateStep) .. " -> " .. hlText(cl) .. "   anchor " .. tostring(PedGetPointer(gPlayer)))
	if not cl or cl[1] < 1 or cl[1] >= 32768 then RP.why = "cannot locate the plugin (closure)"; rpLog(RP.why); return false end
	-- Lua 5.0 CClosure: next(4) tt(1) marked(1) isC(1) nupvalues(1) gclist(4) f(4)
	local words = {}
	for off = 0, 28, 4 do words[table.getn(words) + 1] = hlText(rd32(hlAdd(cl, off))) end
	rpLog("closure words: " .. table.concat(words, " "))
	for _, off in ipairs({ 12, 8, 16, 4, 20, 24, 28 }) do
		local f = rd32(hlAdd(cl, off))
		-- the handler sits at base + 0x51b0 and DLL bases are 64 KB aligned
		if f and f[2] == RP_OFF_STEP and f[1] >= 1 and f[1] < 32768 then
			local base = { f[1], 0 }
			local pb, pf = mkptr(base), mkptr(f)
			local mz = pb and GetString(pb, 2)
			local prologue = pf and GetString(pf, 3)
			local imm = rd32(hlAdd(base, RP_OFF_STEP_MOV))
			local want = hlAdd(base, RP_OFF_SNAP_POSE)
			rpLog("candidate +" .. off .. ": base " .. hlText(base) .. " mz=" .. tostring(mz == "MZ") ..
				" prologue=" .. tostring(prologue == "\131\236\88") .. " imm=" .. hlText(imm) .. " want " .. hlText(want))
			if mz == "MZ" and prologue == "\131\236\88" and hlEq(imm, want) then
				RP.base = base
				RP.pPose = mkptr(hlAdd(base, RP_OFF_RIG_POSE))
				RP.pBoard = mkptr(hlAdd(base, RP_OFF_BOARD_POSE))
				RP.pActive = mkptr(hlAdd(base, RP_OFF_RIG_ACTIVE))
				if not (RP.pPose and RP.pBoard and RP.pActive) then RP.why = "could not build exact pointers"; rpLog(RP.why); return false end
				RP.ok = true
				rpLog("replay editor ready")
				return true
			end
		end
	end
	RP.why = "this BullySkate build is not the one the replay editor was made for (v0.1.2)"
	rpLog(RP.why)
	return false
end

------------------------------------------------------------------ recording
-- called by main.lua every skating frame, after FS_SkateStep
function ReplayRecord(now, x, y, z, heading, hasCamera, cx, cy, cz, fx, fy, fz, lens)
	if replay then return end
	if not RP.ok then
		if RP.checked then return end
		if not ReplayFindPlugin() then return end
	end
	local okP, pose = pcall(GetString, RP.pPose, RP_POSE_BYTES)
	local okB, board = pcall(GetString, RP.pBoard, RP_BOARD_BYTES)
	if not okP or not okB then return end
	local f = { t = now, x = x, y = y, z = z, h = heading, pose = pose, board = board }
	if hasCamera then f.cx, f.cy, f.cz, f.fx, f.fy, f.fz, f.lens = cx, cy, cz, fx, fy, fz, lens end
	RP.head = math.mod(RP.head, REPLAY_CAPACITY) + 1
	RP.frames[RP.head] = f
	if RP.count < REPLAY_CAPACITY then RP.count = RP.count + 1 end
	-- drop anything older than REPLAY_SECONDS
	while RP.count > 1 do
		local oldest = RP.frames[math.mod(RP.head - RP.count + REPLAY_CAPACITY, REPLAY_CAPACITY) + 1]
		if oldest and now - oldest.t > REPLAY_SECONDS * 1000 then RP.count = RP.count - 1 else break end
	end
	RP.lastRec = now
end

-- i-th recorded frame, oldest first (1 .. RP.count)
function ReplayFrameAt(i)
	return RP.frames[math.mod(RP.head - RP.count + i - 1 + REPLAY_CAPACITY, REPLAY_CAPACITY) + 1]
end
------------------------------------------------------------------ editor state
RE_CAMS = { "Default", "Follow", "Fisheye", "Tripod", "Fixed", "Advanced" }
RE_SPEEDS = { 1, 0.5, 0.25, 0.1, 1.5, 2 }
RE_SPEED_NAMES = { "100%", "50%", "25%", "10%", "150%", "200%" }
RE_DEAD = 0.15

local function applyFrame(f)
	if not f or not RP.ok then return end
	pcall(SetString, RP.pPose, f.pose, RP_POSE_BYTES)
	pcall(SetString, RP.pBoard, f.board, RP_BOARD_BYTES)
	pcall(SetString, RP.pActive, "\1\0\0\0", 4)
	PedSetPosSimple(gPlayer, f.x, f.y, f.z)
	PedFaceHeading(gPlayer, f.h * 180 / math.pi, 0)
end

function RE_setCamera(x, y, z, fx, fy, fz, lens)
	CameraSetXYZ(x, y, z, x + fx * 10, y + fy * 10, z + fz * 10)
	if lens then CameraSetFOV(lens) end
	FS_View(x, y, z, fx, fy, fz, lens or 70)
	local R = replay
	if R then R.camNow = { x = x, y = y, z = z, fx = fx, fy = fy, fz = fz } end
end

-- frame index for timeline time t (ms since first frame)
function RE_index(t)
	local first = ReplayFrameAt(1)
	if not first then return 1 end
	local lo, hi = 1, RP.count
	while lo < hi do
		local mid = math.floor((lo + hi + 1) / 2)
		if ReplayFrameAt(mid).t - first.t <= t then lo = mid else hi = mid - 1 end
	end
	return lo
end

function RE_duration()
	if RP.count < 2 then return 0 end
	return ReplayFrameAt(RP.count).t - ReplayFrameAt(1).t
end

function RE_lens(cam)
	if cam and cam.cam == 3 then return 100 end
	return (skaterOptions and skaterOptions[10]) or 70
end

function RE_toast(s, ms)
	if replay then replay.toast = s; replay.toastEnd = GetTimer() + (ms or 2500) end
end

------------------------------------------------------------------ keyframes
-- active keyframe index at time t (last key at or before t), or nil
function RE_active(t)
	local keys = replay.keys
	local found = nil
	for i = 1, table.getn(keys) do
		if keys[i].t <= t + 1 then found = i else break end
	end
	return found
end

function RE_copy(c)
	local n = {}
	for k, v in pairs(c) do n[k] = v end
	return n
end

-- free-camera parameters from what is on screen now
function RE_fromView(c)
	local v = replay.camNow
	if v then
		c.x, c.y, c.z = v.x, v.y, v.z
		c.yaw = math.atan2(v.fx, -v.fy)
		c.pitch = math.asin(clamp(v.fz, -1, 1))
	else
		local f = ReplayFrameAt(RE_index(replay.t))
		c.x, c.y, c.z, c.yaw, c.pitch = f.x, f.y - 4, f.z + 1.5, 0, -0.2
	end
end

function RE_newCam(kind)
	local c = { cam = kind, speed = 1, oyaw = 0, opitch = 0.3, odist = 3.5 }
	if kind == 3 then c.oyaw, c.opitch, c.odist = 0.7, 0.1, 1.6 end
	RE_fromView(c)
	return c
end

-- the camera setup in effect at time t (live = the one you are moving right now)
function RE_camAt(t)
	local R = replay
	if R.live then return R.live, nil end
	local i = RE_active(t)
	if i then return R.keys[i], i end
	return R.defaultCam, nil
end

function RE_speedAt(t)
	local i = RE_active(t)
	if i then return RE_SPEEDS[replay.keys[i].speed] or 1 end
	return 1
end

function RE_setKey()
	local R = replay
	local c = R.live
	if not c then
		local cur = RE_camAt(R.t)
		c = RE_copy(cur)
		if c.cam >= 4 then RE_fromView(c) end
	end
	c = RE_copy(c); c.t = R.t
	local keys = R.keys
	local pos = table.getn(keys) + 1
	for i = 1, table.getn(keys) do
		if math.abs(keys[i].t - c.t) < 40 then
			if not R.live then c.speed = keys[i].speed end
			keys[i] = c; R.live = nil
			RE_toast("Keyframe updated: " .. RE_CAMS[c.cam]); return
		end
		if keys[i].t > c.t then pos = i; break end
	end
	table.insert(keys, pos, c)
	R.live = nil
	RE_toast("Keyframe " .. pos .. " set: " .. RE_CAMS[c.cam])
end

function RE_removeKey()
	local R = replay
	if R.live then R.live = nil; RE_toast("Camera change cancelled"); return end
	local keys = R.keys
	local best, bd = nil, 1e9
	for i = 1, table.getn(keys) do
		local d = math.abs(keys[i].t - R.t)
		if d < bd then best, bd = i, d end
	end
	if not best then RE_toast("No keyframes to remove"); return end
	table.remove(keys, best)
	RE_toast("Keyframe removed")
end

function RE_jumpKey(dir)
	local R = replay
	local keys = R.keys
	local n = table.getn(keys)
	local target = nil
	if dir > 0 then
		for i = 1, n do if keys[i].t > R.t + 20 then target = keys[i].t; break end end
	else
		for i = n, 1, -1 do if keys[i].t < R.t - 20 then target = keys[i].t; break end end
	end
	if not target then RE_toast(n == 0 and "No keyframes yet - D-pad Down sets one" or "No more keyframes that way"); return end
	R.t = target; R.playing = false; R.live = nil
end

function RE_cycleCamera()
	local R = replay
	local cur = RE_camAt(R.t)
	local nextCam = math.mod(cur.cam, table.getn(RE_CAMS)) + 1
	local c = RE_newCam(nextCam)
	c.speed = cur.speed or 1
	-- standing on a keyframe: change that keyframe directly, otherwise preview it
	local i = RE_active(R.t)
	if i and math.abs(R.keys[i].t - R.t) < 40 then
		c.t = R.keys[i].t; R.keys[i] = c; R.live = nil
		RE_toast("Keyframe " .. i .. " camera: " .. RE_CAMS[nextCam])
	else
		R.live = c
		RE_toast("Camera: " .. RE_CAMS[nextCam] .. "  -  D-pad Down to set it as a keyframe", 3500)
	end
end

function RE_cycleSpeed()
	local R = replay
	local i = RE_active(R.t)
	if R.live then R.live.speed = math.mod(R.live.speed or 1, table.getn(RE_SPEEDS)) + 1; RE_toast("Speed " .. RE_SPEED_NAMES[R.live.speed] .. " (set the keyframe to keep it)"); return end
	if not i then RE_toast("Set a keyframe first - speed applies from a keyframe to the next"); return end
	local k = R.keys[i]
	k.speed = math.mod(k.speed or 1, table.getn(RE_SPEEDS)) + 1
	RE_toast("Speed from keyframe " .. i .. ": " .. RE_SPEED_NAMES[k.speed])
end

function RE_videoLength()
	local R = replay
	local a, b = R.inT, R.outT
	local total, t = 0, a
	local keys = R.keys
	while t < b do
		local nextT = b
		for i = 1, table.getn(keys) do if keys[i].t > t + 1 and keys[i].t < nextT then nextT = keys[i].t end end
		total = total + (nextT - t) / RE_speedAt(t)
		t = nextT
	end
	return total
end

------------------------------------------------------------------ cameras
-- direction Jimmy is travelling at time t (no frame-to-frame state, so scrubbing and
-- playing give the same, steady result)
function RE_travelYaw(t, f)
	local R = replay
	local dur = RE_duration()
	local spans = { 600, 1500 }
	for s = 1, 2 do
		local a = ReplayFrameAt(RE_index(math.max(0, t - spans[s])))
		local b = ReplayFrameAt(RE_index(math.min(dur, t + 200)))
		local dx, dy = b.x - a.x, b.y - a.y
		if dx * dx + dy * dy > 0.09 then
			R.travelYaw = math.atan2(dx, -dy)
			return R.travelYaw
		end
	end
	return R.travelYaw or 0
end

function RE_dirOf(c)
	local cp = math.cos(c.pitch)
	return math.sin(c.yaw) * cp, -math.cos(c.yaw) * cp, math.sin(c.pitch)
end

function RE_norm(x, y, z)
	local l = math.sqrt(x * x + y * y + z * z)
	if l < 1e-4 then return 0, 1, 0 end
	return x / l, y / l, z / l
end

-- camera pose {x,y,z,fx,fy,fz,lens} for one camera setup at time t
function RE_pose(c, t, f, yaw0)
	local kind = c.cam
	local tx, ty, tz = f.x, f.y, f.z + 0.9
	if kind == 1 then
		if f.cx then return { f.cx, f.cy, f.cz, f.fx, f.fy, f.fz, f.lens or RE_lens(c) } end
		local fx, fy, fz = RE_norm(0, 4, -0.7)
		return { f.x, f.y - 4, f.z + 1.6, fx, fy, fz, RE_lens(c) }
	elseif kind == 2 or kind == 3 then
		tz = f.z + (c.tz or (kind == 3 and 0.6 or 0.9))
		local yaw = yaw0 + c.oyaw
		local cp = math.cos(c.opitch)
		local x, y, z = tx - math.sin(yaw) * cp * c.odist, ty + math.cos(yaw) * cp * c.odist, tz + math.sin(c.opitch) * c.odist
		local fx, fy, fz = RE_norm(tx - x, ty - y, tz - z)
		return { x, y, z, fx, fy, fz, c.lens or RE_lens(c) }
	elseif kind == 4 then
		local fx, fy, fz = RE_norm(tx - c.x, ty - c.y, tz - c.z)
		return { c.x, c.y, c.z, fx, fy, fz, RE_lens(c) }
	end
	local fx, fy, fz = RE_dirOf(c)
	return { c.x, c.y, c.z, fx, fy, fz, RE_lens(c) }
end

function RE_smooth(u)
	u = clamp(u, 0, 1)
	return u * u * (3 - 2 * u)
end

-- every keyframe glides smoothly into the next one
function RE_showCamera(t, f)
	local R = replay
	local c, i = RE_camAt(t)
	local yaw0 = RE_travelYaw(t, f)
	local b = i and R.keys[i + 1]
	local p
	if not b or (c.cam == 1 and b.cam == 1) then
		p = RE_pose(c, t, f, yaw0)
	else
		local u = RE_smooth((t - c.t) / math.max(1, b.t - c.t))
		local orbitA, orbitB = c.cam == 2 or c.cam == 3, b.cam == 2 or b.cam == 3
		if orbitA and orbitB then
			-- Follow / Fisheye: blend the orbit itself so the camera swings around Jimmy
			local m = { cam = 2,
				oyaw = c.oyaw + (b.oyaw - c.oyaw) * u,
				opitch = c.opitch + (b.opitch - c.opitch) * u,
				odist = c.odist + (b.odist - c.odist) * u,
				tz = (c.cam == 3 and 0.6 or 0.9) + ((b.cam == 3 and 0.6 or 0.9) - (c.cam == 3 and 0.6 or 0.9)) * u,
				lens = RE_lens(c) + (RE_lens(b) - RE_lens(c)) * u }
			p = RE_pose(m, t, f, yaw0)
		else
			local pa, pb = RE_pose(c, t, f, yaw0), RE_pose(b, t, f, yaw0)
			local fx, fy, fz = RE_norm(pa[4] + (pb[4] - pa[4]) * u, pa[5] + (pb[5] - pa[5]) * u, pa[6] + (pb[6] - pa[6]) * u)
			p = { pa[1] + (pb[1] - pa[1]) * u, pa[2] + (pb[2] - pa[2]) * u, pa[3] + (pb[3] - pa[3]) * u, fx, fy, fz, pa[7] + (pb[7] - pa[7]) * u }
		end
	end
	RE_setCamera(p[1], p[2], p[3], p[4], p[5], p[6], p[7])
end

-- sticks move the camera you are setting up (makes it a "live" unsaved change)
function RE_moveCamera(dt, lx, ly, rx, ry)
	local R = replay
	if math.abs(lx) < RE_DEAD then lx = 0 end
	if math.abs(ly) < RE_DEAD then ly = 0 end
	if math.abs(rx) < RE_DEAD then rx = 0 end
	if math.abs(ry) < RE_DEAD then ry = 0 end
	if lx == 0 and ly == 0 and rx == 0 and ry == 0 then return end
	local cur = RE_camAt(R.t)
	if cur.cam == 1 then
		if not R.warnedDefault then RE_toast("The Default camera follows your skating - press Y for a camera you can move", 3500); R.warnedDefault = true end
		return
	end
	if not R.live then
		R.live = RE_copy(cur); R.live.t = nil
		if cur.cam >= 4 then RE_fromView(R.live) end
		RE_toast("Camera moved - D-pad Down to set it as a keyframe", 3500)
	end
	local c = R.live
	if c.cam == 2 or c.cam == 3 then
		c.oyaw = c.oyaw - rx * 2.0 * dt
		c.opitch = clamp(c.opitch - ry * 1.2 * dt, -0.25, 1.3)
		c.odist = clamp(c.odist - ly * 4 * dt, 0.8, 15)
	else
		if c.cam == 4 then
			local f = ReplayFrameAt(RE_index(R.t))
			local dx, dy, dz = f.x - c.x, f.y - c.y, f.z + 0.9 - c.z
			c.yaw = math.atan2(dx, -dy)
			c.pitch = math.asin(clamp(dz / math.max(0.01, math.sqrt(dx * dx + dy * dy + dz * dz)), -1, 1))
		else
			c.yaw = c.yaw - rx * 2.1 * dt
			c.pitch = clamp(c.pitch + ry * 1.5 * dt, -1.5, 1.5)
		end
		local fx, fy, fz = RE_dirOf(c)
		local mag = math.max(math.abs(lx), math.abs(ly))
		local sp = 1.5 + 10 * mag * mag
		c.x = c.x + (fx * ly - math.cos(c.yaw) * lx) * sp * dt
		c.y = c.y + (fy * ly - math.sin(c.yaw) * lx) * sp * dt
		c.z = c.z + fz * ly * sp * dt
	end
end

------------------------------------------------------------------ open / close
function ReplayOpen()
	if replay then return end
	if mode ~= 1 or not physicalBoard then say("Start skating first - the replay records while you skate"); return end
	if not ReplayFindPlugin() then say("Replay editor unavailable: " .. RP.why); return end
	if RP.count < 30 then say("Nothing recorded yet - skate for a few seconds first"); return end
	if menu then EditorClose() end
	if debugCamera then DebugCameraClose(false) end
	SkateAudioStop()
	local dur = RE_duration()
	replay = {
		mode = "timeline", t = dur, playing = false, keys = {}, live = nil,
		inT = math.max(0, dur - 15000), outT = dur, viewA = 0, viewB = dur,
		defaultCam = { cam = 1, speed = 1, oyaw = 0, opitch = 0.3, odist = 3.5 },
		hideUI = false, help = false, toast = nil, toastEnd = 0, held = {},
	}
	pcall(HUDSaveVisibility); pcall(HUDClearAllElements)
	hintEnd = 0
	rpLog(string.format("editor opened: %d frames, %.1f s", RP.count, dur / 1000))
end

function ReplayHudHidden() return replay ~= nil and replay.hideUI end

function ReplayClose()
	if not replay then return end
	replay = nil
	pcall(HUDRestoreVisibility)
	-- BullyMotion's loop restores the live pose, position and camera next frame
	say("Back to skating")
end

------------------------------------------------------------------ one editor frame
-- called from BullyMotion's main loop instead of skating
function ReplayUpdate(now, dt, buttons, lx, ly, rx, ry, lt, rt, pressed)
	local R = replay
	if not R then return end
	if mode ~= 1 or not physicalBoard then ReplayClose(); return end
	local dur = RE_duration()
	if R.outT > dur then R.outT = dur end

	-- keyboard equivalents
	local _, kSpace = key(32); local _, kEsc = key(27); local _, kEnter = key(13); local _, kC = key(67)
	local _, kK = key(75); local _, kDel = key(46); local _, kH = key(72); local _, kP = key(80); local _, kF1 = key(112)
	local kLeft = key(37); local kRight = key(39)

	local lb = bit(buttons, 256)
	R.held.rb = bit(buttons, 512); R.held.lt = lt > 0.1 or kLeft; R.held.rt = rt > 0.1 or kRight
	R.held.dd = bit(buttons, 2); R.held.du = bit(buttons, 1); R.held.dl = bit(buttons, 4); R.held.dr = bit(buttons, 8)
	R.held.lbls = lb and math.abs(lx) > RE_DEAD; R.held.lbrs = lb and math.abs(rx) > RE_DEAD

	if pressed(64) or kH then R.hideUI = not R.hideUI end
	if R.help then
		if pressed(32) or pressed(8192) or kF1 or kEsc then R.help = false end
	elseif pressed(32) or kF1 then R.help = true
	end

	if R.mode == "photo" then
		if pressed(8192) or pressed(16384) or kEsc or kP then R.mode = R.photoBack or "timeline"; R.live = R.photoLive; R.hideUI = false
		else RE_moveCamera(dt, lx, ly, rx, ry) end
		local f = ReplayFrameAt(RE_index(R.t))
		applyFrame(f)
		RE_showCamera(R.t, f)
		return
	end

	if not R.help then
		if pressed(8192) or kEsc then
			if R.live then R.live = nil; RE_toast("Camera change cancelled")
			elseif R.mode == "clip" then R.mode = "timeline"; R.playing = false
			else ReplayClose(); return end
		end
		if pressed(512) or kSpace then
			R.playing = not R.playing
			if R.playing and R.mode == "clip" and (R.t >= R.outT - 10 or R.t < R.inT) then R.t = R.inT end
			if R.playing and R.t >= dur - 10 then R.t = 0 end
		end
		if pressed(2) or kK then RE_setKey() end
		if pressed(1) or kDel then RE_removeKey() end
		if pressed(4) then RE_jumpKey(-1) end
		if pressed(8) then RE_jumpKey(1) end
		if pressed(32768) or kC then RE_cycleCamera() end
		if pressed(4096) or kEnter then
			if R.mode == "timeline" then
				R.mode = "clip"; R.playing = false
				if R.t < R.inT or R.t > R.outT then R.t = R.inT end
			else R.mode = "timeline"; R.playing = false end
		end
		if pressed(16384) or kP then
			if R.mode == "timeline" then
				R.photoBack = R.mode; R.photoLive = R.live; R.playing = false
				R.live = RE_newCam(5); R.mode = "photo"; R.photoStart = GetTimer()
				return
			else RE_cycleSpeed() end
		end
	end

	-- LB + sticks choose the clip start / end; otherwise the sticks move the camera
	if lb then
		if math.abs(lx) > RE_DEAD then
			R.inT = clamp(R.inT + lx * math.abs(lx) * dt * 8000, 0, R.outT - 500); R.t = R.inT; R.playing = false
		end
		if math.abs(rx) > RE_DEAD then
			R.outT = clamp(R.outT + rx * math.abs(rx) * dt * 8000, R.inT + 500, dur); R.t = R.outT; R.playing = false
		end
	elseif not R.help then
		RE_moveCamera(dt, lx, ly, rx, ry)
	end

	-- triggers: rewind / fast forward, harder = faster
	local tr = rt - lt
	if kRight then tr = 0.6 elseif kLeft then tr = -0.6 end
	if math.abs(tr) > 0.1 then
		R.playing = false
		local s = 0.15 + 3.85 * tr * tr
		if tr < 0 then s = -s end
		R.t = R.t + s * dt * 1000
	end

	if R.playing then
		R.t = R.t + dt * 1000 * RE_speedAt(R.t)
		if R.mode == "clip" then
			if R.t >= R.outT then R.t = R.inT end
		elseif R.t >= dur then R.t = dur; R.playing = false end
	end
	if R.mode == "clip" then R.t = clamp(R.t, R.inT, R.outT) else R.t = clamp(R.t, 0, dur) end

	-- timeline zoom (Edit Clip zooms in on the chosen start and end)
	local wa, wb = 0, dur
	if R.mode == "clip" then wa, wb = R.inT, R.outT end
	local k = math.min(1, dt * 9)
	R.viewA = R.viewA + (wa - R.viewA) * k
	R.viewB = R.viewB + (wb - R.viewB) * k

	local f = ReplayFrameAt(RE_index(R.t))
	applyFrame(f)
	RE_showCamera(R.t, f)
end

------------------------------------------------------------------ shortcuts
function ReplayShortcuts(buttons, oldButtons)
	local _, f4 = key(115)
	local chord = bit(buttons, 128) and bit(buttons, 1) and not (bit(oldButtons, 128) and bit(oldButtons, 1))
	if f4 or chord then
		if replay then ReplayClose() else ReplayOpen() end
		return true
	end
	return false
end
------------------------------------------------------------------ drawing (Skate 3 layout)
RE_TEX = {}
RE_TEX_W = { -- source widths in pixels (all 64 tall)
	chip_rb_play = 120, chip_lt_rew = 120, chip_rt_ff = 120, chip_dd_add = 120, chip_du_del = 122,
	chip_dl_prev = 126, chip_dr_next = 126, chip_lb_ls = 196, chip_lb_rs = 196,
}
function RE_loadTextures()
	local names = { "chip_rb_play", "chip_lt_rew", "chip_rt_ff", "chip_dd_add", "chip_du_del", "chip_dl_prev", "chip_dr_next",
		"chip_lb_ls", "chip_lb_rs", "btn_a", "btn_b", "btn_x", "btn_y", "btn_back", "btn_ls_click", "btn_ls", "btn_rs",
		"btn_lb", "btn_rb", "btn_lt", "btn_rt", "btn_dpad_d", "btn_dpad_u", "btn_dpad_l", "btn_dpad_r" }
	for i = 1, table.getn(names) do
		local ok, tex = pcall(CreateTexture, "ui/replay/" .. names[i] .. ".png")
		if ok and tex then RE_TEX[names[i]] = tex end
	end
end
pcall(RE_loadTextures)

function RE_aspect()
	local ok, _, w, h = pcall(FS_VideoStats)
	if ok and type(w) == "number" and type(h) == "number" and w > 0 and h > 0 then return h / w end
	return 0.5625
end

function RE_label(s, x, y, size, r, g, b)
	SetTextFont("Arial"); SetTextHeight(size); SetTextPosition(x, y); SetTextAlign("LEFT", "TOP")
	SetTextColor(r or 255, g or 255, b or 255, 255); SetTextShadow(0, 0, 0); DrawText(s)
end

-- rough text width (screen-width units) for Arial at this height
function RE_textW(s, size) return string.len(s) * size * 0.50 * RE_aspect() end

-- one icon; returns its width
function RE_icon(name, x, y, h, srcW)
	local w = h * ((srcW or 64) / 64) * RE_aspect()
	local tex = RE_TEX[name]
	if tex then DrawTexture(tex, x, y, w, h)
	else
		DrawRectangle(x, y + h * 0.1, w, h * 0.8, 52, 55, 60, 230)
		RE_label(string.upper(string.gsub(string.gsub(name, "^chip_", ""), "^btn_", "")), x + w * 0.08, y + h * 0.3, h * 0.38)
	end
	return w
end

function RE_chipRow(list, y, h)
	local gap = 0.003
	local total = -gap
	for i = 1, table.getn(list) do total = total + h * (RE_TEX_W[list[i][1]] / 64) * RE_aspect() + gap end
	local x = 0.4975 - total / 2
	for i = 1, table.getn(list) do
		local w = RE_icon(list[i][1], x, y, h, RE_TEX_W[list[i][1]])
		if list[i][2] then DrawRectangle(x + w * 0.03, y + h * 0.07, w * 0.94, h * 0.86, 255, 255, 255, 55) end
		x = x + w + gap
	end
end

-- bottom bar prompts, laid out right to left from x1
function RE_prompts(list, x1, y, size)
	local x = x1
	for i = table.getn(list), 1, -1 do
		local p = list[i]
		x = x - RE_textW(p[2], size)
		RE_label(p[2], x, y + size * 0.05, size)
		local ih = size * 1.35
		local iw = ih * RE_aspect()
		x = x - iw - 0.003
		RE_icon(p[1], x, y - size * 0.15, ih)
		x = x - 0.012
	end
end

function RE_marker(x, y0, y1, thick, cap, r, g, b)
	DrawRectangle(x - thick / 2, y0, thick, y1 - y0, r, g, b, 255)
	if cap > 0 then
		DrawRectangle(x - cap / 2, y0, cap, 0.005, r, g, b, 255)
		DrawRectangle(x - cap / 2, y1 - 0.005, cap, 0.005, r, g, b, 255)
	end
end

function RE_diamond(x, y, s, r, g, b)
	local a = RE_aspect()
	for i = 0, 3 do
		local hw = s * (4 - i) / 4 * a
		DrawRectangle(x - hw, y - s + i * s / 4, hw * 2, s / 4 + 0.0006, r, g, b, 255)
		DrawRectangle(x - hw, y + s - (i + 1) * s / 4, hw * 2, s / 4 + 0.0006, r, g, b, 255)
	end
end

function RE_timeline(R, dur)
	local X0, X1, Y, H = 0.178, 0.817, 0.072, 0.046
	local W = X1 - X0
	local a, b = R.viewA, math.max(R.viewA + 1, R.viewB)
	local function px(t) return X0 + W * clamp((t - a) / (b - a), 0, 1) end
	local function visible(t) return t >= a - 1 and t <= b + 1 end
	-- end caps and film strip
	DrawRectangle(X0 - 0.007, Y - 0.004, 0.007, H + 0.008, 55, 150, 180, 235)
	DrawRectangle(X1, Y - 0.004, 0.007, H + 0.008, 55, 150, 180, 235)
	DrawRectangle(X0, Y, W, H, 30, 32, 36, 225)
	local step = 0.0105
	local x = X0 + 0.003
	while x < X1 - 0.006 do
		DrawRectangle(x, Y + 0.004, 0.005, 0.006, 78, 80, 86, 230)
		DrawRectangle(x, Y + H - 0.010, 0.005, 0.006, 78, 80, 86, 230)
		x = x + step
	end
	-- the chosen clip
	local ca, cb = px(R.inT), px(R.outT)
	if cb > ca then
		DrawRectangle(ca, Y + 0.003, cb - ca, H / 2 - 0.003, 232, 241, 250, 240)
		DrawRectangle(ca, Y + H / 2, cb - ca, H / 2 - 0.003, 196, 216, 238, 240)
	end
	-- keyframes (orange markers, like the d-pad icons)
	for i = 1, table.getn(R.keys) do
		local k = R.keys[i]
		if visible(k.t) then RE_marker(px(k.t), Y + 0.006, Y + H - 0.006, 0.0028, 0.008, 238, 140, 40) end
	end
	-- clip start / end brackets
	if visible(R.inT) then RE_marker(ca, Y - 0.010, Y + H + 0.010, 0.0042, 0.012, 238, 140, 40) end
	if visible(R.outT) then RE_marker(cb, Y - 0.010, Y + H + 0.010, 0.0042, 0.012, 238, 140, 40) end
	-- playhead
	local p = px(R.t)
	DrawRectangle(p - 0.0008, Y, 0.0016, H, 70, 175, 245, 230)
	RE_diamond(p, Y + 0.002, 0.012, 70, 175, 245)
end

function ReplayDraw()
	local R = replay
	if not R then return end
	local dur = math.max(1, RE_duration())
	local now = GetTimer()
	if R.mode == "photo" then
		if now - (R.photoStart or 0) < 4500 then
			RE_label("Photo mode: line up your shot with the sticks, then press F12 to save a Steam screenshot.   B: back", 0.18, 0.885, 0.022)
		end
		return
	end
	if R.hideUI then return end

	RE_timeline(R, dur)
	local h = 0.056
	RE_chipRow({ { "chip_rb_play", R.held.rb }, { "chip_lt_rew", R.held.lt }, { "chip_rt_ff", R.held.rt },
		{ "chip_dd_add", R.held.dd }, { "chip_du_del", R.held.du }, { "chip_dl_prev", R.held.dl }, { "chip_dr_next", R.held.dr } }, 0.122, h)
	RE_chipRow({ { "chip_lb_ls", R.held.lbls }, { "chip_lb_rs", R.held.lbrs } }, 0.183, h)

	-- above the bar: hide prompt, status / messages, estimated length
	local s = 0.024
	local iw = RE_icon("btn_ls_click", 0.176, 0.806, 0.048)
	RE_label("Hide", 0.176 + iw + 0.002, 0.833, s)
	if R.toast and now < R.toastEnd then RE_label(R.toast, 0.245, 0.797, s, 255, 214, 120) end
	local status
	do
		local c, i = RE_camAt(R.t)
		if R.live then status = "Camera: " .. RE_CAMS[c.cam] .. " (not set yet - D-pad Down)"
		elseif i then status = "Keyframe " .. i .. " of " .. table.getn(R.keys) .. "   " .. RE_CAMS[c.cam] .. "   " .. RE_SPEED_NAMES[c.speed or 1]
		else status = "Camera: " .. RE_CAMS[c.cam] .. "   " .. table.getn(R.keys) .. " keyframes" end
	end
	RE_label(status, 0.245, 0.833, s, 225, 232, 240)
	local est = "Estimated Video Length: " .. math.floor(RE_videoLength() / 1000 + 0.5) .. " s"
	RE_label(est, 0.815 - RE_textW(est, s), 0.833, s, 232, 96, 86)

	-- bottom bar
	DrawRectangle(0.175, 0.872, 0.642, 0.046, 58, 80, 124, 175)
	DrawRectangle(0.175, 0.872, 0.642, 0.002, 205, 220, 240, 230)
	DrawRectangle(0.175, 0.916, 0.642, 0.002, 205, 220, 240, 230)
	local cur = RE_camAt(R.t)
	local ps = 0.025
	if R.mode == "clip" then
		RE_label("Edit clip", 0.184, 0.881, ps)
		RE_prompts({ { "btn_y", "Camera: " .. RE_CAMS[cur.cam] }, { "btn_x", "Speed: " .. RE_SPEED_NAMES[cur.speed or 1] },
			{ "btn_a", "Done" }, { "btn_b", "Back" }, { "btn_back", "Help" } }, 0.811, 0.881, ps)
	else
		RE_label("Edit timeline", 0.184, 0.881, ps)
		RE_prompts({ { "btn_a", "Edit Clip" }, { "btn_y", "Camera: " .. RE_CAMS[cur.cam] }, { "btn_x", "Take Photo" },
			{ "btn_b", "Exit" }, { "btn_back", "Help" } }, 0.811, 0.881, ps)
	end

	if R.help then RE_drawHelp() end
end

function RE_drawHelp()
	DrawRectangle(0.27, 0.27, 0.46, 0.52, 18, 30, 62, 225)
	DrawRectangle(0.27, 0.27, 0.46, 0.003, 140, 165, 210, 230)
	DrawRectangle(0.27, 0.787, 0.46, 0.003, 140, 165, 210, 230)
	RE_label("Replay Editor - Help", 0.29, 0.285, 0.03, 232, 241, 250)
	local lines = {
		{ "btn_rb", "Play / pause" },
		{ "btn_lt", "Rewind     (RT: fast forward - press harder to go faster)" },
		{ "btn_dpad_d", "Set a keyframe here with the camera you have set up" },
		{ "btn_dpad_u", "Remove the nearest keyframe" },
		{ "btn_dpad_l", "Jump to the previous keyframe     (Right: next)" },
		{ "btn_lb", "+ LS: choose the clip start     + RS: choose the clip end" },
		{ "btn_y", "Change camera: Default, Follow, Fisheye, Tripod, Fixed, Advanced" },
		{ "btn_rs", "Move the camera (Follow: orbit / distance, others: fly + look)" },
		{ "btn_a", "Edit Clip: zoom in on the clip; X there sets the speed" },
		{ "btn_x", "Take Photo: free camera with no HUD, F12 saves a screenshot" },
	}
	local y = 0.335
	for i = 1, table.getn(lines) do
		local w = RE_icon(lines[i][1], 0.29, y - 0.004, 0.034)
		RE_label(lines[i][2], 0.29 + 0.032, y, 0.019)
		y = y + 0.041
	end
	RE_label("The camera glides smoothly from each keyframe to the next.  Back / B: close", 0.29, 0.752, 0.017, 170, 190, 220)
end

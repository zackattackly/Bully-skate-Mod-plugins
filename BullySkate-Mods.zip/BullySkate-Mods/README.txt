BULLYSKATE MODS - Replay Editor, Object Dropper, Extra Grind Rails, World Options
==============================================================================

These are add-ons for BullySkate v0.1.2 (the Skate 3 physics mod for Bully: Scholarship
Edition). They only work on top of a working BullySkate install.


WHAT'S IN THIS FOLDER
---------------------

  BullyMotion\                    <- copy everything in here into BullySkate's script folder
     replay.lua                   Skate 3 style replay editor (new file)
     dropper.lua                  Object dropper (new file)
     dropper_catalog.lua          Object dropper's list of objects, collision and grind rails (new file)
     world.lua                    Pedestrians on/off and mission-prompt hiding (new file)
     main.lua                     BullySkate's main script with the hooks for the mods above (REPLACES the original)
     editor.lua                   BullySkate's F8 menu with the new menu items (REPLACES the original)
     config.ini                   BullySkate's script settings + file access for the dropper (REPLACES the original)
     ui\replay\*.png              Button prompt images for the replay editor and dropper (new folder)
     assets\world.bmrails         Grind rails for the whole map: BullySkate's rails plus 966 extra
                                  ledges and 52 stair handrails (REPLACES the original)

  Originals\                      BullySkate's untouched files, to undo everything (see UNINSTALL)

  README.txt                      This file


REQUIREMENTS
------------

 1. Bully: Scholarship Edition (Steam).
 2. BullySkate v0.1.2 installed and working (Derpy's Script Loader 15.3 + Ultimate ASI Loader
    + BullySkate.asi, set up by BullySkate's launcher).
 3. SilentPatchBully installed in the Bully folder. Without it, BullySkate can stop the game
    with "requires a DirectX 9.0c compatible sound card".

 The modified main.lua / editor.lua are made from BullySkate v0.1.2. If BullySkate is updated
 to a newer version, don't copy these two over the new ones - the mods would need updating.


WHERE TO INSTALL
----------------

 Bully's folder (Steam default):
   C:\Program Files (x86)\Steam\steamapps\common\Bully Scholarship Edition\

 BullySkate's script folder inside it:
   C:\Program Files (x86)\Steam\steamapps\common\Bully Scholarship Edition\_derpy_script_loader\scripts\BullyMotion\

 (If Steam is on another drive: in Steam right-click Bully > Manage > Browse local files,
  then open _derpy_script_loader > scripts > BullyMotion.)


HOW TO INSTALL
--------------

 1. Close Bully.
 2. Make sure BullySkate is installed and working first (run its launcher once if needed).
 3. Open this folder's  BullyMotion  folder, select everything inside it (Ctrl+A) and copy it.
 4. Paste it into the game's  ...\_derpy_script_loader\scripts\BullyMotion\  folder.
    When Windows asks, choose "Replace the files in the destination".
    (The  ui  and  assets  folders merge with the ones already there - that's correct.)
 5. Start Bully FROM STEAM (not from the BullySkate launcher - see IMPORTANT below).

 That's it. Nothing goes in the main Bully folder.


IMPORTANT - LAUNCH FROM STEAM
-----------------------------

 BullySkate's launcher checks its own files and puts its originals back if anything changed.
 Running it would undo main.lua, editor.lua, config.ini and world.bmrails. After installing
 these mods, start the game from Steam. If you do run the launcher, just copy the
 BullyMotion folder in again afterwards.


CONTROLS AND FEATURES
---------------------

 REPLAY EDITOR (Skate 3 layout)
   Open / close ......... Right stick click + D-pad Up   (keyboard F4)
   It records the last 60 seconds of skating automatically.

   RB ................... play / pause
   LT / RT .............. rewind / fast forward (press harder = faster)
   D-pad Down ........... set a keyframe (with the camera you've set up)
   D-pad Up ............. remove the nearest keyframe
   D-pad Left / Right ... jump between keyframes
   LB + LS .............. choose the clip start
   LB + RS .............. choose the clip end
   Y .................... change camera: Default, Follow, Fisheye, Tripod, Fixed, Advanced
   Sticks ............... move the camera you're setting up
                          (Follow / Fisheye: RS orbit, LS distance; others: LS fly, RS look)
   A .................... Edit Clip - zooms the timeline in on your start and end
                          (inside Edit Clip, X sets the speed from that keyframe)
   X .................... Take Photo - free camera with no HUD; press F12 for a Steam screenshot
   LS click ............. hide all the editor's on-screen text
   Back ................. help screen
   B .................... exit (or back out of Edit Clip)
   The camera glides smoothly from each keyframe to the next.

 OBJECT DROPPER
   Open ................. RB + B   (keyboard F3)   or "Object dropper" in the F8 menu
   Categories: Rails, Ramps, Benches, Misc (all Bully's own props, with collision and grind rails)

   LS ................... move the object
   RS ................... turn the camera (up / down = zoom)
   LB / RB .............. rotate (tap = 15 degrees, hold = smooth)
   LT / RT .............. lower / raise the object
   LS click ............. put it back on the ground
   D-pad Up / Down ...... change category
   D-pad Left / Right ... change object
   A .................... drop it
   X .................... remove the nearest object
   Y .................... pick up the nearest object (to move it)
   Back (twice) ......... remove all objects
   B .................... done - Jimmy gets back on the board with the new objects skateable

   Up to 24 objects. They're saved and come back next time you play.
   Rails get one grind line down the top centre; Misc objects get grind lines on their sharp
   edges; ramps and benches on their top edges.

 F8 MENU - NEW ITEMS
   Pedestrians ......... On / Off. Off clears the people around you and stops new ones
                         spawning. Turn it On for story missions.
   Mission prompts ..... Hidden / Shown. Hidden clears mission and objective text while you
                         skate (help-box tips still show).
   Object dropper ...... opens the object dropper.

 EXTRA GRIND RAILS (assets\world.bmrails)
   Ledges NPCs sit on, low walls, planters, the fountain rim and more (966 added), plus
   handrails on stairs (52 added: pool, library, chem plant, warehouse, Old Bullworth Vale
   and others). Benches already had rails in BullySkate.


FILES THE MODS CREATE BY THEMSELVES (don't copy these between PCs)
-------------------------------------------------------------------

 In the BullyMotion folder, once you use the mods:
   replay_debug.txt, replay_guard.txt        replay editor's start-up check
   world_settings.txt                        your Pedestrians / Mission prompts choices
   dropper_objects.txt                       your placed objects
   dropper_state.txt, dropper_debug.txt      object dropper bookkeeping
   assets\world.bmgeo.base                   backup of the original collision file
   assets\world.bmrails.base                 backup of the rail file
 The dropper adds your objects' collision to assets\world.bmgeo and assets\world.bmrails, and
 puts the clean versions back when you remove all objects.


TROUBLESHOOTING
---------------

 * "Replay editor unavailable ... crashed during setup last time"
     Delete  replay_guard.txt  in the BullyMotion folder and start the game again.
 * "Replay editor unavailable: this BullySkate build is not the one..."
     Your BullySkate isn't v0.1.2 - the replay editor reads v0.1.2's memory layout.
 * Objects you removed are still solid (invisible collision):
     Open the dropper, press Back twice (remove all), then B. If it still happens, close Bully,
     copy  assets\world.bmgeo.base  over  assets\world.bmgeo  and
     assets\world.bmrails.base  over  assets\world.bmrails, and delete dropper_objects.txt.
 * Everything stopped working after running BullySkate's launcher:
     Copy this BullyMotion folder in again (see IMPORTANT - LAUNCH FROM STEAM).
 * A dropped object's collision faces the wrong way to the model:
     In dropper.lua change  DROP_ROT_SIGN = 1  to  DROP_ROT_SIGN = -1.


UNINSTALL
---------

 1. Close Bully. Open the game's  ...\_derpy_script_loader\scripts\BullyMotion\  folder.
 2. If you placed objects: start the game once, open the dropper, press Back twice, then B,
    and quit. (Or copy the .base files back as in TROUBLESHOOTING.)
 3. Copy the four files from this folder's  Originals  folder back:
      main.lua, editor.lua, config.ini   ->  BullyMotion\
      world.bmrails                      ->  BullyMotion\assets\
 4. Delete  replay.lua, dropper.lua, dropper_catalog.lua, world.lua  and the  ui\replay  folder.
 5. You can also delete the files listed under FILES THE MODS CREATE BY THEMSELVES.

 (Running BullySkate's launcher also puts back its original files.)
